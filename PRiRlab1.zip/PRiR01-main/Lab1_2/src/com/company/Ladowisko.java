package com.company;

public class Ladowisko
{
    static int LADOWISKO = 1;
    static int START = 2;
    static int LOT = 3;
    static int KONIECLOTU = 4;
    static int KATASTROFA = 5;

    int iloscMiejsc;
    int iloscZajetych;
    int iloscHelikopterow;

    Ladowisko(int iloscMiejsc, int iloscHelikopterow)
    {
        this.iloscMiejsc = iloscMiejsc;
        this.iloscHelikopterow = iloscHelikopterow;
        this.iloscZajetych = 0;
    }
    synchronized int start(int numer)
    {
        iloscZajetych--;
        System.out.println("Pozwolenie na start helikopterowi nr: " + numer);
        return START;
    }
    synchronized int laduj()
    {
        try
        {
            Thread.currentThread().sleep(1000);
        }
        catch (Exception e)
        {

        }
        if(iloscZajetych < iloscMiejsc)
        {
            iloscZajetych++;
            System.out.println("Pozwolenie ladowania na miejscu nr: " + iloscZajetych);
            return LADOWISKO;
        }
        else
            return KONIECLOTU;
    }
    synchronized void zmniejsz()
    {
        iloscHelikopterow--;
        System.out.println("Zmniejszono ilosc");
        if(iloscHelikopterow == iloscMiejsc)
            System.out.println("Ilosc samolotow jest taka sama jak ilosc miejsc");
    }
}
