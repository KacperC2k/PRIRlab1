package com.company;

public class Main
{

    public static int n = 500;
    public static double a = 1;
    public static double b = 8;
    public static double dx = (b - a) / n;


    public static void main(String[] args)
    {
        Prostokat[] watkiProstokatow = new Prostokat[n];
        Simpson[] watkiSimpsona = new Simpson[n - 1];
        Trapez[] watkiTrapezow = new Trapez[n - 1];

        double wynikProstokatow = 0;
        double wynikSimpsona = 0;
        double wynikTrapezow = 0;

        double S = 0;

        for(int i = 1; i <= n; i++)
        {
            watkiProstokatow[i - 1] = new Prostokat(a + ((i - 1) * dx), a + (i * dx));
            watkiProstokatow[i - 1].start();
            if(i != n)
            {
                watkiTrapezow[i - 1] = new Trapez(a + ((i - 1) * dx), a + (i * dx));
                watkiSimpsona[i - 1] = new Simpson(a + ((i - 1) * dx), a + (i * dx), dx);
                watkiTrapezow[i - 1].start();
                watkiSimpsona[i - 1].start();
            }
        }
        for(int i = 1; i <= n; i++)
        {
            try
            {
                watkiProstokatow[i - 1].join();
                wynikProstokatow += watkiProstokatow[i - 1].wynik;
                if(i != n)
                {
                    watkiTrapezow[i - 1].join();
                    watkiSimpsona[i - 1].join();
                    wynikTrapezow += watkiTrapezow[i - 1].wynik;
                    wynikSimpsona += watkiSimpsona[i - 1].wynik;
                    S += watkiSimpsona[i - 1].s;
                }
            }
            catch (Exception e){}
        }
        System.out.println("Wynik metody prostokątów to: " + wynikProstokatow * dx);
        wynikTrapezow += ((Trapez.f(a) + Trapez.f(b)) / 2);
        System.out.println("Wynik metody trapezów to: " + wynikTrapezow * dx);
        S += Simpson.f(b - dx / 2);
        System.out.println("Wynik metody simpsona to: " + ((dx/6) * (Simpson.f(a) + Simpson.f(b) + 2 * wynikSimpsona + 4 * S)));

    }
}
