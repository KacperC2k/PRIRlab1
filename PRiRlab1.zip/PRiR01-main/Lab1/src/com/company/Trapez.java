package com.company;

public class Trapez extends Thread
{

    double a;
    double b;
    double wynik;

    public Trapez(double a, double b)
    {
        this.a = a;
        this.b = b;
    }

    public static double f(double x)
    {
        return x*x+3;
    }

    public void run()
    {
        wynik = f(b);
    }
}
